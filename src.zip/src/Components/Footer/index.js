import React from 'react';
import {Row, Col} from 'reactstrap';
//import './Footer.css';
const Footer=()=> {  
    return (
     <Row>
		<Col lg="12">
			<div className="text-center">&copy; All Rights Reserved eCom Inc.</div>
		</Col>		
	 </Row>
    );
}

export default Footer;